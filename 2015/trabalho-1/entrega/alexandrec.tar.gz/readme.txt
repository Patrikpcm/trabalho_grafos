

O arquivo grafo.c que acompanha este arquivo deveria ser a versao definitiva de entrega.

Eu era um dos alunos que enviou email a respeito de mais trabalhos para serem entregues
mas na ultima aula achei que poderia fazer o trabalho dentro do prazo mas me enganei 
por alguns minutos. Quando estava para se encerrar o prazo estava terminando a parte
que trata diferentemente arestas de grafos direcionados e nao direcionados. Os minutos
excedentes foram para ajustes, testes e para escrever este arquivo.

A versao anterior trata todos os grafos como direcionados. Este ja faz distincao como
no exemplo enviado no pacote do trabalho 1.

Esta versao esta mais completa, melhor comentada e a unica diferenca da saida para o
programa exemplo esta com o processamento do cidades.dot, porque para atender as 
especificacoes, o peso das arestas esta representado (e eh impresso) como double, 
diferente do programa exemplo onde o peso e um string.

Sei que esta escrito no "perguntas frequentes" da pagina que o trabalho aceito seria
o ultimo enviado dentro do prazo no entando acho decepcionante nao poder mostrar que
o atraso nao foi por descaso mas simplesmente por ter gastado horas e horas tentando
resolver problemas da linguagem ( vide malloc(0) no codigo que evita que os dados do array
sejam corrompidos ou que causem segmentation fault apos o array ser parcialmente preenchido )
ou mesmo tentando entender por que a biblioteca nao estava sendo considerada pelo compilador,
ate que foi corrigido pela observacao de um colega.

Como esta escrito na pagina, o trabalho efetivo para correcao eh o que foi entregue ha uns 
50 minutos atras entao sei que a aceitacao ou nao desta versao fica a criterio.

Professor, tenha uma otima semana.

