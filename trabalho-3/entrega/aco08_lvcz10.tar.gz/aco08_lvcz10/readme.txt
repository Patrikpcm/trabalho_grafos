
	Trabalho 3 de Algoritmos e Teoria dos Grafos:
    
    O objetivo deste trabalho é implementar uma subrotina que computa
    um emparelhamento máximo em um grafo bipartido.
    
    A função emparelhamento_maximo(grafo g) devolve um grafo cujos 
    vertices são cópias de vértices do grafo bipartido g e cujas arestas
    formam um emparelhamento máximo em g.
    O grafo devolvido, portanto, é vazio ou tem todos os vértices com 
    grau 1. Não verifica se g é bipartido; caso não seja, o comportamento
    é indefinido.

	Participantes:

		Alexandre Calerio de Oliveira 		GRR20080568
		Leonardo Vincius Carvalho Zanella	GRR20103241
